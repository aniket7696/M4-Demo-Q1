﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DB2View.Models;

namespace DB2View.Controllers
{
    public class StudentController : Controller
    {
        Training_24Oct18_PuneEntities context = new Training_24Oct18_PuneEntities();

        // GET: Student
        public ActionResult Index()
        {
            var query = context.Student_master.Where(s=>s.Address=="Mumbai");
            ViewBag.StudList = query.ToList();
            return View();
        }

        public ActionResult Query1()
        {
            var query = context.Student_master.Where(s => s.Address == "Pune" && s.Stud_Dob.Value.Year==1995).OrderByDescending(s => s.Stud_Name);
            ViewBag.StudList = query.ToList();
            return View();
        }



        public ActionResult Query2()
        {
            var query = context.Student_master.Where(s => s.Address == string.Empty );
            ViewBag.StudList = query.ToList();
            return View();
        }



        public ActionResult Query3()
        {
            var query = context.Student_master.Where(s => s.Stud_Dob.Value.Year > 1989 && s.Stud_Dob.Value.Year < 1996);
            ViewBag.StudList = query.ToList();
            return View();
        }

        public ActionResult Query4()
        {
            var query = context.Student_master.Where(s=>s.Stud_Dob.Value >= new DateTime(1991,6,1) && s.Stud_Dob.Value <=new DateTime(1994,4,4));
            ViewBag.StudList = query.ToList();
            return View();
        }

        public ActionResult Query5()
        {
            var query = context.Student_master.Where(s => s.Dept_Code == 10 || s.Address == "Pune");
            ViewBag.StudList = query.ToList();
            return View();
        }
    }
}